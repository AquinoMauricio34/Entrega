#ifndef MODIFICAR_SERVICIOS_C
#define MODIFICAR_SERVICIOS_C

#include<stdio.h>
#include<stdlib.h>
#include"../estructuras.h"
#include"../prototipos.h"

/*
by hugo
*/
void modificar_servicios() {
    printf("Chau melani\n");
    system("pause");
}

#endif //MODIFICAR_SERVICIOS_C